import { useState } from 'react';
import './App.css';
import Home from './Home';
import './App.css';


function App() {
  return (
    <div>
      <Home />
    </div>
  );
}

export default App;
